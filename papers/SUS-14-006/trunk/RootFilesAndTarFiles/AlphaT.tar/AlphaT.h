#include <cmath>
#include <numeric>
#include <vector>


/*  AlphaT
 *
 *  Calculates the AlphaT event variable for a given input jet collection
 *
 */

struct AlphaT {

  static double getAlphaT( const std::vector<double>& et,
			   const std::vector<double>& px,
			   const std::vector<double>& py,
			   std::vector<int> * jet_pseudoFlag,
			   double& minDeltaHT);
  
};

