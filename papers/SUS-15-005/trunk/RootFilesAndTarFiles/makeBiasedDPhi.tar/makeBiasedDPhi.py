from math import sqrt, sin, cos, atan2, pi

def deltaPhi( p1, p2):
	'''Computes delta phi, handling periodic limit conditions.'''
	res = p1 - p2
	while res > pi:
		res -= 2*pi
	while res < -pi:
		res += 2*pi
	return res

def makeBiasedDPhi(jet_pt,jet_phi,mht_pt,mht_phi):
        mhtpx,mhtpy = mht_pt*cos(mht_phi),-mht_pt*sin(mht_phi)
        jetpx,jetpy = jet_pt*cos(jet_phi),-jet_pt*sin(jet_phi)
        newPhi = atan2(-mhtpy-jetpy,mhtpx+jetpx)
        biasedDPhi = abs(deltaPhi(newPhi,jet_phi))
	return biasedDPhi

def makeMinBiasedDPhi(jets,mht_pt,mht_phi):
    if len(jets) < 2:
        return 99,-1,None
    bDPhiList = []
    for jet in jets:
        bDPhiList.append(makeBiasedDPhi(jet.pt,jet.phi,mht_pt,mht_phi))
    tempBiasedDPhi = min(bDPhiList)
    bIndex = bDPhiList.index(tempBiasedDPhi)
    tempBiasedDPhiJet = jets[bIndex]
    return bIndex,tempBiasedDPhi,tempBiasedDPhiJet

