from math import fabs, sqrt, sin, cos, atan, atan2, exp

def makeMHT(jets):
    tempVec =[0,0]
    for jet in jets:
        tempVec[0] -= jet.pt*cos(jet.phi)
        tempVec[1] += jet.pt*sin(jet.phi)

    mhtPt = sqrt(tempVec[0]**2+tempVec[1]**2)
    mhtPhi = atan2(-tempVec[1],tempVec[0])
        
    return mhtPt,mhtPhi

def makeAlphaT(alljets):

    jets = alljets[:10]

    if len(jets) < 2:
        return -1

    for jet in jets:
        jet.theta = 2*atan(exp(-jet.eta))
        jet.et = sqrt(jet.pt**2 + (jet.mass*sin(jet.theta))**2)

    nJet   = len(jets)
    ht     = sum([jet.et for jet in jets])
    mht,_  = makeMHT(jets)

    minDeltaHt = -1
    # loop over possible combinations
    for i in range( 1 << (nJet-1) ):
        deltaHt = 0
        # loop over jets
        for j in range(nJet):
            deltaHt += jets[j].et * ( 1 - 2 * (int(i>>j)&1) )
        if fabs(deltaHt) < minDeltaHt or minDeltaHt < 0:
            minDeltaHt = fabs(deltaHt)

    return 0.5 * ( ht - minDeltaHt ) / sqrt( ht*ht - mht*mht )

